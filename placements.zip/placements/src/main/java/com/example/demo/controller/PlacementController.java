package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Placement;
import com.example.demo.services.PlacementServices;

@RestController
public class PlacementController {

	@Autowired
	PlacementServices ps1;
	
	@PostMapping("/placements")
	public Placement savePlacement(@RequestBody Placement placement)
	{
		return ps1.savePlacement(placement);
	}
	
	
	
}
