package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Placement {
	@Id
	@GeneratedValue (strategy=GenerationType.AUTO)
	private String id;
	private String Name;
	private int year;
	private String qualification;
	
	public Placement(String id, String name, int year, String qualification) {
		super();
		this.id = id;
		Name = name;
		this.year = year;
		this.qualification = qualification;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	@Override
	public String toString() {
		return "Placement [id=" + id + ", Name=" + Name + ", year=" + year + ", qualification=" + qualification + "]";
	}
	
	
	

}
