package com.example.demo.services;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Placement;

@Service
public interface PlacementServices {
Placement savePlacement(Placement placement);
}
