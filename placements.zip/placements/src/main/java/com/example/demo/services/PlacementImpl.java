package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Placement;
import com.example.demo.repository.PlacementRepository;

@Service
public class PlacementImpl implements PlacementServices {

	@Autowired
	PlacementRepository pr1;
	
	
	@Override
	public Placement savePlacement(Placement placement) {
		// TODO Auto-generated method stub
		return pr1.save(placement) ;
	}
	
}
